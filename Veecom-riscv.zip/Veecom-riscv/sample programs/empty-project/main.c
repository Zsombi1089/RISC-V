#include "utility.h"

int main(void)
{

  dma_write("Powered by RISC-V");

  for (;;)
    ;
}
