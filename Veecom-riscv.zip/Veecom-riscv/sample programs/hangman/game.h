#ifndef GAME_H
#define GAME_H

void Game_Init(void);
void Game_Reset(void);
void Game_Run(void);

#endif