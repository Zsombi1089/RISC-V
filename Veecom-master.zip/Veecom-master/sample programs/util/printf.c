// mini_printf.c
#include "utility.h"
#include <stdarg.h>

// Csak string kiírás
int printf_(const char* format, ...)
{
    va_list args;
    va_start(args, format);

    // Mivel nincs formázás, csak a format stringet írjuk ki
    dma_write((char*)format);

    va_end(args);
    return 0; // visszatérési érték ignorálható
}

// Ha bufferbe szeretnéd írni:
int sprintf_(char* buffer, const char* format, ...)
{
    va_list args;
    va_start(args, format);

    // Formázás nélkül csak bemásoljuk a stringet
    char* p = (char*)format;
    while (*p) {
        *buffer++ = *p++;
    }
    *buffer = '\0';

    va_end(args);
    return 0;
}
