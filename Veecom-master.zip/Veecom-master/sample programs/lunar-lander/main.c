#include "game.h"

int main(void)
{
    Game_Init();
    Game_Run();

    for (;;)
        ;
}
