#!/bin/bash
set -e

# Fordító és beállítások
CC=riscv64-unknown-elf-gcc
RV_CFG="-march=rv32im -mabi=ilp32"
CFLAGS="-c $RV_CFG -I ../util/ -I /usr/lib/picolibc/riscv64-unknown-elf/include -O0"
LDFLAGS="-nostartfiles -ffunction-sections $RV_CFG -T ../linker.ld --specs=/usr/lib/picolibc/riscv64-unknown-elf/picolibc.specs"

# Forrásfájlok
SRC_FILES="main.c ../util/startup.c ../util/utility.c ../util/printf.c"
OBJS=$(echo $SRC_FILES | sed 's/\.c/\.o/g')

# Fordítás
echo "[1/3] Fordítás..."
for src in $SRC_FILES; do
    obj=${src%.c}.o
    echo "   $src -> $obj"
    $CC $CFLAGS -o $obj $src
done

# Linkelés
echo "[2/3] Linkelés..."
$CC $LDFLAGS $OBJS -o final.elf

# Bináris készítés
echo "[3/3] Bináris generálás..."
riscv64-unknown-elf-objcopy -O binary final.elf final.bin

echo "Kész: final.elf és final.bin"
