#include "utility.h"

void szoveg(char szoveg[]){
	dma_write(szoveg);
}

void main()
{
    int magassag = 5;
    int a;
    int x = magassag;
    int y = 1;
    int z;
    
    while(x!=0){
    
        for(a=1;a<x;a++){
        	szoveg(" ");
    	}
        for(z=y;z!=0;--z){
        	szoveg("*");
        }
    	for(a=1;a<x;a++){
        	szoveg(" ");
    	}
        szoveg("\n");
    	--x;
        y=y+2;
    }
}
